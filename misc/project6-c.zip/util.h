//
// STARTER CODE: util.h
//
// Conrado Manzano: Project 6, CS251, Fall 2021
//

#pragma once
#include <utility>
#include <iostream>
#include <fstream>
#include <map>
#include <unordered_map>
#include <queue>          // std::priority_queue
#include <vector>         // std::vector
#include <functional>     // std::greater
#include <string>
#include "bitstream.h"
#include "util.h"
#include "hashmap.h"
#include "mymap.h"

struct HuffmanNode {
    int character;
    int count;
    HuffmanNode* zero;
    HuffmanNode* one;
};

// class for priority_queue to order HuffmanNodes by count
class prioritize {
  public:
    bool operator()(const pair<HuffmanNode*, int>& p1,
                    const pair<HuffmanNode*, int>& p2) const {
      return p1.second > p2.second;
    }
};

//
// *This method frees the memory allocated for the Huffman tree.
//
void freeTree(HuffmanNode* node) {
  if (node == nullptr) {
    return;
  } else {
    freeTree(node->zero);
    freeTree(node->one);
    delete node;
  }
}

//
// *This function build the frequency map.  If isFile is true, then it reads
// from filename.  If isFile is false, then it reads from a string filename.
//
void buildFrequencyMap(string filename, bool isFile, hashmap &map) {
  //file
  if (isFile == true) {
    ifstream inFS(filename);
    char c;
    while (inFS.get(c)) {
      int key = int(c);  // convert the char to an int
      if (map.containsKey(key) == false) {
        map.put(key, 1);
      } else {
        // if it exists just add one to val
        int val = map.get(key);
        val += 1;
        map.put(key, val);
      }
    }
  } else {  // for strings
    for (char c : filename) {
      int key = int(c);
      if (map.containsKey(key) == false) {
        map.put(key, 1);
      } else {
        int val = map.get(key);
        val += 1;
        map.put(key, val);
      }
    }
  }
    // put EOF
  map.put(256, 1);
}

//
// *This function builds an encoding tree from the frequency map.
//
HuffmanNode* buildEncodingTree(hashmap &map) {
  // create the priority queue
  priority_queue<
    pair<HuffmanNode*, int>,
    vector<pair<HuffmanNode*, int>>,
    prioritize> pq;

  // fill the priority queue with values from the ap
  for (int k : map.keys()) {
    HuffmanNode* n = new HuffmanNode();  // create a new node
    int value = map.get(k);  // get the value from the map
    n->character = k;  // assign character and count
    n->count = value;
    n->zero = nullptr;
    n->one = nullptr;
    pq.push(pair<HuffmanNode*, int>(n, n->count));  // push back into queue
  }

  HuffmanNode* n = nullptr;
  HuffmanNode* first = nullptr;
  HuffmanNode* second = nullptr;
  // loop through pq to create tree
  while (pq.size() > 1) {  // stop before the last node
    pair<HuffmanNode*, int> top = pq.top();  // grab first node
    pq.pop();  // pop that node
    first = top.first;
    top = pq.top();  // grab second node
    pq.pop();  // pop that node
    second = top.first;
    n = new HuffmanNode();  // create new node
    n->character = NOT_A_CHAR;  // create new node N_A_C
    // assign new node count to total count
    n->count = first->count + second->count;
    n->zero = first;  // assign first node to left
    n->one = second;  // assign second node to right
    pq.push(pair<HuffmanNode*, int>(n, n->count));  // enqueue new node
  }
  // get the last node, it is root
  pair<HuffmanNode*, int> root = pq.top();
  pq.pop();  // pop last node
  return root.first;
}

// helper function for buildEncodingMap
void traverseEnc(HuffmanNode* tree, string binary,
                 mymap<int, string>& encodingMap) {
  if (tree == nullptr) {
    return;
  } else {
    // pushing all of the characters and binary string
    if (tree->character != NOT_A_CHAR) {
      encodingMap.put(tree->character, binary);
    }
    binary += "0";  // adds a zero when it goes left
    traverseEnc(tree->zero, binary, encodingMap);
    binary.pop_back();
    binary += "1";  // adds a 1 when it goes right
    traverseEnc(tree->one, binary, encodingMap);
    binary.pop_back();
  }
}

//
// *This function builds the encoding map from an encoding tree.
//
mymap <int, string> buildEncodingMap(HuffmanNode* tree) {
    mymap <int, string> encodingMap;
  string binary = "";

  traverseEnc(tree, binary, encodingMap);

  return encodingMap;
}

// helper function to check when makeFile is true, 
// this will be called when makefile is true
void checkFile(string &result, ofbitstream& output) {
  for (char c : result) {
    if (c == '1') {
      output.writeBit(1);
    } else {
      output.writeBit(0);
    }
  }
}

// helper function to traverse lines
void helpEncode(string binEncode, mymap <int, string> &encodingMap,
                int &size, bool line, string &result) {
  if (line == true) {  // encode the whole string
    for (char c : binEncode) {
      for (char x : encodingMap.get(c)) {
        result += x;
        size++;
      }
    }
  } else {
    // encode the endline
    for (char x : encodingMap.get('\n')) {
      result += x;
      size++;
    }
  }
}

//
// *This function encodes the data in the input stream into the output stream
// using the encodingMap.  This function calculates the number of bits
// written to the output stream and sets result to the size parameter, which is
// passed by reference.  This function also returns a string representation of
// the output file, which is particularly useful for testing.
//
string encode(ifstream& input, mymap <int, string> &encodingMap,
              ofbitstream& output, int &size, bool makeFile) {
  string result = "";
  string binEncode;
  getline(input, binEncode);
  helpEncode(binEncode, encodingMap, size, true, result);

  while (!input.eof()) {  // call the helper function for the whole string
    helpEncode(binEncode, encodingMap, size, false, result);
    getline(input, binEncode);
    helpEncode(binEncode, encodingMap, size, true, result);
  }
  // add the end of file character at the end
  for (char x : encodingMap.get(PSEUDO_EOF)) {
    result += x;
    size++;
  }
  if (makeFile == true) {
    checkFile(result, output);
  }
  return result;
}

//
// *This function decodes the input stream and writes the result to the output
// stream using the encodingTree.  This function also returns a string
// representation of the output file, which is particularly useful for testing.
//
string decode(ifbitstream &input, HuffmanNode* encodingTree, ofstream &output) {
  HuffmanNode* cur = encodingTree;
  int val = input.readBit();  // get the bit to know to go left or right
  string result = "";
  while (cur->character != PSEUDO_EOF) {
    if (cur->character != NOT_A_CHAR) {  // if its a char store it
      result += cur->character;
      cur = encodingTree;
    }
    if (val == 0) {
      cur = cur->zero;
    } else {
      cur = cur->one;
    }
    val = input.readBit();
  }
  output << result;
  return result;
}

//
// *This function completes the entire compression process.  Given a file,
// filename, this function (1) builds a frequency map; (2) builds an encoding
// tree; (3) builds an encoding map; (4) encodes the file (don't forget to
// include the frequency map in the header of the output file).  This function
// should create a compressed file named (filename + ".huf") and should also
// return a string version of the bit pattern.
//
string compress(string filename) {
  // call all functions in order to properly compress a file
  hashmap frequencyMap;
  buildFrequencyMap(filename, true, frequencyMap);
  HuffmanNode* encodedTree = buildEncodingTree(frequencyMap);
  mymap<int, string> encodedMap = buildEncodingMap(encodedTree);
  int size = 0;
  ifstream input(filename);
  ofbitstream output(filename + ".huf");
  output << frequencyMap;
  string result = encode(input, encodedMap, output, size, true);
  freeTree(encodedTree);
  input.close();
  output.close();
  return result;
}

//
// *This function completes the entire decompression process.  Given the file,
// filename (which should end with ".huf"), (1) extract the header and build
// the frequency map; (2) build an encoding tree from the frequency map; (3)
// using the encoding tree to decode the file.  This function should create a
// compressed file using the following convention.
// If filename = "example.txt.huf", then the uncompressed file should be named
// "example_unc.txt".  The function should return a string version of the
// uncompressed file.  Note: this function should reverse what the compress
// function did.
//
string decompress(string filename) {
  hashmap frequencyMap;
  // need to properly get the filename without the filetype to change the filetype
  int huf = filename.find(".huf");
  string subFile = filename.substr(0, huf);
  int dot = subFile.find(".");
  string period = subFile.substr(dot, subFile.length() - dot);
  filename = subFile.substr(0, dot);
  ifbitstream input(filename + period + ".huf");
  ofstream output(filename + "_unc" + period);
  input >> frequencyMap;  // get the frequencyMap
  // create the encoded tree from the map and then decode said tree
  HuffmanNode* encodedTree = buildEncodingTree(frequencyMap);
  string result = decode(input, encodedTree, output);
  freeTree(encodedTree);
  return result;
}
